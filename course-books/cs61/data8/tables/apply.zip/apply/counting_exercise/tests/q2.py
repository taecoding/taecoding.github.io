test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> exercise_with_totals.take(range(5))
          Day (in January) | yoga | walking | sprinting | volleyball | Total calories burned exercising
          1                | 50   | 0       | 0         | 0          | 300
          2                | 0    | 65      | 0         | 65         | 585
          3                | 50   | 70      | 0         | 0          | 650
          4                | 0    | 0       | 0         | 75         | 300
          5                | 0    | 0       | 0         | 0          | 0
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
